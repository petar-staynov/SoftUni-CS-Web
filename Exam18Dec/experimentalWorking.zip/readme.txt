Everything working except total sum for receipts and css for receipt details
Uses a modified SIS framework that works with lowercase routes
If this version doesnt work pls check the previous submission