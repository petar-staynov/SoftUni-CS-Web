﻿namespace MUSAKA.Common.Models.View
{
    public class LoginUserBindingModel
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}