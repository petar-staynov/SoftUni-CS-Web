﻿namespace MUSAKA.Common.Models.View
{
    public class AddProductBindingModel
    {
        public string Barcode { get; set; }
        public string Quantity { get; set; }
    }
}