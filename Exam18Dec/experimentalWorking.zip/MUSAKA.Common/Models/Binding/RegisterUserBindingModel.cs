﻿namespace MUSAKA.Common.Models.View
{
    public class RegisterUserBindingModel
    {
        public string username { get; set; }
        public string password { get; set; }
        public string confirmPassword { get; set; }
        public string email { get; set; }
    }
}