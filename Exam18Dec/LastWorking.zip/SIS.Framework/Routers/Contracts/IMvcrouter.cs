﻿using SIS.WebServer.Api;

namespace SIS.Framework.Routers.Contracts
{
    public interface IMvcRouter : IHttpRequestHandler
    {
    }
}
