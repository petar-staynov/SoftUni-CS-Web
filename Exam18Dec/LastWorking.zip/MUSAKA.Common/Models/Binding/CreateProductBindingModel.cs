﻿namespace MUSAKA.Common.Models.View
{
    public class CreateProductBindingModel
    {
        public string Name { get; set; }

        public string Picture { get; set; }

        public decimal Price { get; set; }

        public string Barcode { get; set; }
    }
}