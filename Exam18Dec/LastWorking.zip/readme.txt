Everything working except receipt details and total sums for receipts
Uses a modified SIS framework that works with lowercase routes